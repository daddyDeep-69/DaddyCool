#include<iostream>
#include<cstring>
#include"Address.h"
using namespace std;

//Default Constructor
Address :: Address(){
    houseNo=0;
    colony[0]='\0';
    area[0]='\0';
    city[0]='\0';
    pinCode =000000;
}

//Parameterised Constructor
Address :: Address(int houseNo,char colony[], char area[], char city[], int pinCode){
    this->houseNo=houseNo;
    strcpy(this->colony,colony);
    strcpy(this->area,area);
    strcpy(this->city,city);
    this->pinCode =pinCode;
}
void Address::accept(){
    cout<<"Enter House No.: ";
    cin>>houseNo;
    cout<<"Enter Colony: ";
    cin>>colony;
    cout<<"Enter Area: ";
    cin>>area;
    cout<<"Enter City: ";
    cin>>city;
    cout<<"Enter Pincode: ";
    cin>>pinCode;
}

void Address::display(){
    cout<<"Address: ";
    cout<<houseNo<<", "<<colony<<", "<<area<<", "<<city<<", "<<pinCode<<endl;
}

void Address::operator==(Address adr1){
    if(this->houseNo==adr1.houseNo){
        cout<<"Address is Same"<<endl;
    }
    else
        cout<<"Address is Not Same"<<endl;
}

//Destructor
Address::~Address(){
    cout<<"Destructor called"<<endl;
}