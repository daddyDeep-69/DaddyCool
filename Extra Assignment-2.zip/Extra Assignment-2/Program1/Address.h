class Address
{
    private:
    int houseNo;
    char colony[100];
    char area[100];
    char city[100];
    int pinCode;

    public:
    Address();
    Address(int houseNo,char colony[], char area[], char city[], int pinCode);

    void accept();
    void display();

    void operator==(Address adr1);
    ~Address();
};