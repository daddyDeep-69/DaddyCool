#include<iostream>
#include "Address.h"
using namespace std;

int main(){
    char carr[100]="Panchwati";
    char aarr[100]="Pashan";
    char ciarr[100]="Pune";

    Address adr1;
    Address adr2(10,carr,aarr,ciarr,426542);
    adr1.accept();
    adr1.display();
    adr2.display();
    adr1==adr2;
    return 0;

}