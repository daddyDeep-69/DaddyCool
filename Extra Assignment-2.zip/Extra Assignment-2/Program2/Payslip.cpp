#include<iostream>
#include<cstring>
#include"Payslip.h"
using namespace std;

Payslip::Payslip()
{
    EmpNo = 0;
    EmpName[0] = '\0';
    DA = 0;
    HRA = 0;
    BasicSalary = 0;
    status = 0;
}

Payslip::Payslip(int EmpNo, char EmpName[], int DA, int HRA, int BasicSalary, int status)
{
    EmpNo = EmpNo;
    strcpy(this->EmpName, EmpName);
    DA = DA;
    HRA = HRA;
    BasicSalary = BasicSalary;
    status = status;
}

void Payslip::Accept()
{
    cout<<endl;
    cout<<"Enter Employee No: ";
    cin>>EmpNo;
    cout<<"Enter Employee Name: ";
    cin>>EmpName;
    cout<<"Enter DA: ";
    cin>>DA;
    cout<<"Enter HRA: ";
    cin>>HRA;
    cout<<"Enter BasicSalary: ";
    cin>>BasicSalary;
    cout<<"1. Employee 2.HR 3.Manager: ";
    cin>>status; 
}

void Payslip::Display()
{
    cout<<endl;
    cout<<"Employee Details: "<<endl;
    //out<<EmpNo<<", "<<EmpName<<", "<<DA<<", "<<HRA<<", "<<BasicSalary;
    cout<<"Employee No: "<<EmpNo<<endl;
    cout<<"Employee Name: "<<EmpName<<endl;
    cout<<"Employee DA: "<<DA<<endl;
    cout<<"Employee HRA: "<<HRA<<endl;
    cout<<"Employee Basic Salary: "<<BasicSalary<<endl;
    cout<<"Employee Role: ";
    if (status==1) cout<<" Employee"<<endl;
    else if (status==2) cout<<" HR"<<endl;
    else if (status==3) cout<<" Manager"<<endl;
    else cout<<"Contract Based Employeer"<<endl;
}

void Payslip::CalculateSalary()
{
    int result;

    if(status==1) result = BasicSalary;
    else if (status==2) result = HRA + BasicSalary;
    else if (status==3) result = HRA + DA + BasicSalary;
    else {cout<<"Contract Based Does not have salary"<<endl; result = 0;}

    cout<<"Salary of "<<this->EmpName<<" is: "<<result<<endl;
}

Payslip::~Payslip()
{
    cout<<"Destructor reached"<<endl;
}