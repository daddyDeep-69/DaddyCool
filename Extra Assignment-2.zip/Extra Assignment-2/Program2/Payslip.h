class Payslip
{
    private:
    int EmpNo;
    char EmpName[100];
    int DA;
    int HRA;
    int BasicSalary;
    int status;

    public:
    Payslip();
    Payslip(int EmpNo, char EmpName[], int DA, int HRA, int BasicSalary, int status);
    void Accept();
    void Display();
    void CalculateSalary();
    ~Payslip();
};