#include<iostream>
#include"Payslip.h"
#include<cstring>
using namespace std;

int main()
{
    char name[100] = "ABCDE"; 

    Payslip Emp1;
    Emp1.Accept();
    Emp1.Display();
    Emp1.CalculateSalary();

    Payslip Emp2;
    Emp2.Accept();
    Emp2.Display();
    Emp2.CalculateSalary();

    Payslip Emp3;
    Emp3.Accept();
    Emp3.Display();
    Emp3.CalculateSalary();
}