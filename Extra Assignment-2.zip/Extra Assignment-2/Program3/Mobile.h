class Mobile
{
    private:
    int ModelNo;
    int Price;
    char Manufacturer[100];
    int Quantity;
    int type;

    public:
    Mobile();
    Mobile(int mn, int p, char mf[], int q, int t);
    void accept();
    void Display();
    static void mAva(Mobile MM[], int n);
    static void qmt(Mobile MM[], int n);
    ~Mobile();
};