#include<iostream>
#include"Mobile.h"
using namespace std;

int main()
{
    int choice;
    int n;

    cout<<"Enter number models to enter: ";
    cin>>n;

    Mobile MM[n];

    do
    {
        cout<<"Menu:"<<endl;
        cout<<"1. Add Mobile"<<endl;
        cout<<"2. Display List"<<endl;
        cout<<"3. Quantity of Model"<<endl;
        cout<<"4. Availability of Model"<<endl;
        cout<<"5. Exit"<<endl;
        cout<<"Enter Choice: ";
        cin>>choice;

        switch (choice)
        {
        case 1:
            for (int i=0; i < n; i++)
            {
                MM[i].accept();
            }
            break;

        case 2:
            for (int i=0; i < n; i++)
            {
                MM[i].Display();
            }
            break;

        case 3:
            Mobile::qmt(MM, n);
            break;

        case 4:
            Mobile::mAva(MM, n);
            break;
        
        case 5:
            cout<<"Exited Successfully"<<endl;
            break;

        default:
            cout<<"Invalid choice enter again :)"<<endl;
            break;
        }
    } while (choice!=5);
}