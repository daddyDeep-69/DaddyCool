#include<iostream>
#include"Mobile.h"
#include<cstring>
using namespace std;

Mobile::Mobile()
{
    ModelNo = 0;
    Price = 0;
    Manufacturer[0] = '\0';
    Quantity = 0;
    type = 0;
}

Mobile::Mobile(int mn, int p, char mf[], int q, int t)
{
    ModelNo = mn;
    Price = p;
    strcpy(this->Manufacturer, mf);
    Quantity = q;
    type = t;
}

void Mobile::accept()
{
    
        cout<<"Enter Details: "<<endl;
        cout<<"Enter model No: ";
        cin>>this->ModelNo;
        cout<<"Enter Price: ";
        cin>>this->Price;
        cout<<"Enter Manufacturer: ";
        cin>>this->Manufacturer;
        cout<<"Enter Quantity: ";
        cin>>this->Quantity;
        cout<<"Enter type 1. Android 2. IOS: ";
        cin>>this->type;
}

void Mobile::Display()
{
    
        cout<<"Model Details"<<endl;
        cout<<"Model No: "<<ModelNo<<endl;
        cout<<"Price Per Unit: "<<Price<<endl;
        cout<<"Manufacturer: "<<Manufacturer<<endl;
        cout<<"Quantity: "<<Quantity<<endl;
        cout<<"Type: ";
        if (type==1) cout<<"Android"<<endl;
        else cout<<"IOS"<<endl;

}

void Mobile::mAva(Mobile MM[], int n)
{
    int modelNo;
    cout<<"Enter model number to search availability: ";
    cin>>modelNo;

    for (int i=0; i<n; i++)
    {
        if(MM[i].ModelNo == modelNo)
        {
            cout<<"Yes!, Model is available"<<endl;
        }
        else 
        {
            cout<<"No!, Model is not available"<<endl;
        }
    }

}

void Mobile::qmt(Mobile MM[], int n)
{
    int TypeNo;
    cout<<"Enter model type to check quantity: ";
    cout<<"1. Android 2. IOS";
    cin>>TypeNo;

    int typeQuant = 0;

    for (int i=0; i<n; i++)
    {
        if(MM[i].type == TypeNo)
        {
            typeQuant += MM[i].Quantity;
        }
    }

    if(TypeNo==1) cout<<"Quantity of Android is: "<<typeQuant<<endl;
    else cout<<"Quantity of IOS is: "<<typeQuant<<endl;
}

Mobile::~Mobile()
{
    cout<<"Destructor reached"<<endl;
}