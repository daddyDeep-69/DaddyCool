#include<iostream>
using namespace std;
int main(){

    int m,n;
    char choice;
    cout<<"Enter 1st Operand: ";
    cin>>m;
    cout<<"Enter 2nd Operand: ";
    cin>>n;
    
    do{
        cout<<"\n  Calculator"<<endl;
        cout<<"1. Addition (+)"<<endl;
        cout<<"2. Subtraction (-)"<<endl;
        cout<<"3. Multiplication (*)"<<endl;
        cout<<"4. Division (/)"<<endl;
        cout<<"5. Modulus (%)"<<endl;
        cout<<"6. Exit(x)"<<endl;
        cout<<"Enter Operator: ";
        cin>>choice;

        switch(choice){

            case '+':
            {
                cout<<"Addition of "<<m<<" and "<<n<<" is "<<m+n<<endl;
                break;
            }

            case '-':
            {
                cout<<"Subtraction of "<<m<<" and "<<n<<" is "<<m-n<<endl;
                break;
            }
            case '*':
            {
                cout<<"Multiplication of "<<m<<" and "<<n<<" is "<<m*n<<endl;
                break;
            }
            case '/':
            {
                cout<<"Division of "<<m<<" and "<<n<<" is "<<m/n<<endl;
                break;
            }
            case '%':
            {
                cout<<"Modulus of "<<m<<" and "<<n<<" is "<<m%n<<endl;
                break;
            }
            case 'x':
            {
                cout<<"Exiting....."<<endl;
                break;
            }
            default:
            {
                cout<<"Invalid Choice, Please Try Again!!!"<<endl;
                break;
            }
        }

    }while(choice!='x');
    return 0;
}