#include<iostream>
using namespace std;

double acceptMarks(int arr[])
{
    double sum=0;

    for(int i=0;i<5;i++){
        cout<<"Enter marks of "<<i+1<<" : ";
        cin>>arr[i];
    }

    for(int j=0;j<5;j++)
    {
        sum+= arr[j];
    }
    
    return sum/5;
}

void noOfMarks(int arr[]){

    for(int i=0;i<5;i++)
    {
        if (arr[i]<65)
            cout<<"Marks less than 65: "<<arr[i]<<endl;
    }

}

int main()
{
    int arr[5];
    double avg=acceptMarks(arr);
    cout<<"Average of marks is: "<<avg<<endl;
    noOfMarks(arr);
    return 0;
}