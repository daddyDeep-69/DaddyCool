#include<iostream>
#include<cstring>
#include<string>
using namespace std;

int main(){
    string str1;
    string str2;
    cout<<"Enter First String: ";
    cin>>str1;
    cout<<"Enter Second String: ";
    cin>>str2;

    int res = str1.compare(str2);
    if(res==0){
        cout<<"Entered Strings are Same"<<endl;
    }
    else
        cout<<"Entered Strings are Different"<<endl;
    return 0;
}