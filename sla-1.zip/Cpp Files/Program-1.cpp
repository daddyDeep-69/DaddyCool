#include <iostream>
using namespace std;

// Function for calculating Compound Interest 
double calAmount(double p,double r ,double t ){
	double base = 1 + (r/100);
	double result = 1 ;
	for(int i=1;i<=t;i++){
		result *= base;
	}
	return p*result;
}

// Function for calculating Simple Interest 
double calSimpleInt(double p, double r , double t ){
	double result=(p*r*t)/100;
    return result;
}

int main(){

	double  p , r , t ; //p - Principle , r - Rate , t - Time 
	cout<<"Enter Principle: ";
	cin>>p;

    cout<<"Enter Rate: ";
	cin>>r;

    cout<<"Enter Time : ";
	cin>>t;

	double a = calAmount(p,r,t);  ; //a -Total Amount
	
    cout<<"Simple Interest is: "<<calSimpleInt(p,r,t)<<endl;

    cout<<"Compound Interest is: "<<a-p<<endl;

	return 0 ;
}