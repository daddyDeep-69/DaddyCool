#include<iostream>
#include<string>
using namespace std;

class Student
{
    private:
    string name[100];
    int marks1;
    int marks2;
    int marks3;
    int rollNo;
    public:
    Student()
    {
        name[0] = '\0';
        marks1=0;
        marks2=0;
        marks3=0;
        rollNo=0;
    }

    void getData(int n)
    {
        cout<<"Enter Name: ";
        cin>>this->name[n];
        cout<<"Enter Marks of English: ";
        cin>>this->marks1;
        cout<<"Enter Marks of Maths: ";
        cin>>this->marks2;
        cout<<"Enter Marks of Science: ";
        cin>>this->marks3;
    }

    void result(int i)
    {
        if (marks1>=50 && marks2>=50 && marks3>=50) 
           cout<<this->name[i]<<" is Pass."<<endl;

        else 
        cout<<this->name[i]<<" is Fail."<<endl;

    }
};

int main()
{

    int n, i;
    cout << "Enter Number of Student: ";
    cin >> n;

    Student sds[n];
    
    for(i = 0; i < n; i++) 
    {
        sds[i].getData(i);
        sds[i].result(i);
    }

    cout<<endl;
    
    return 0;
}