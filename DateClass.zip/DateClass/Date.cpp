#include<iostream>
#include"Date.h"
using namespace std;

Date::Date()
{
    dd = 1;
    mm = 1;
    yyyy = 1;
}

Date::Date(int date, int month, int year)
{
    dd = date;
    mm = month;
    yyyy = year;
}

Date Date::operator+(Date d1)
{
    Date temp;
    temp.dd=this->dd+d1.dd;
    temp.mm=(this->mm+d1.mm);
    temp.yyyy=this->yyyy+(d1.yyyy%100);
    return temp;
}

Date Date::operator-(Date d1)
{
    Date temp;
    temp.dd=this->dd-d1.dd;
    temp.mm=(this->mm-d1.mm);
    temp.yyyy=(this->yyyy)-(d1.yyyy%100);
    return temp;
}

bool Date::operator<(Date d1)
{
    if (this->dd<d1.dd && this->mm<d1.mm && this->yyyy<d1.yyyy) return true;

    else return false;
}

bool Date::operator==(Date d1)
{
    if (this->dd==d1.dd && this->mm==d1.mm && this->yyyy==d1.yyyy) return true;

    else return false;
}

bool Date::operator!=(Date d1)
{
    if (this->dd!=d1.dd && this->mm!=d1.mm && this->yyyy!=d1.yyyy) return true;

    else return false;
}

void Date::display()
{
        cout<<this->dd<<" / "<<this->mm<<" / "<<this->yyyy<<endl;
}

Date::~Date() {}