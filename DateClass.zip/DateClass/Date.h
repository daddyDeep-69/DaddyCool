class Date
{
    private:
    int dd;
    int mm;
    int yyyy; 

    public:
    Date();
    Date(int date, int month, int year);
    Date operator-(Date d1);
    Date operator+(Date d1);
    bool operator < (Date d1);
    bool operator == (Date d1);
    bool operator != (Date d1);
    void display();
    ~Date();
};