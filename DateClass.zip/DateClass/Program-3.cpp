#include<iostream>
#include"Date.h"
using namespace std;

int main()
{
    Date d1(20, 8, 2015);
    Date d2(5, 3, 2005);

    cout<<"Date 1: ";
    d1.display();
    cout<<"Date 2: ";
    d2.display();

    Date d3 = d1 - d2;
    cout<<"Difference between Date 1 and Date 2: ";
    d3.display();

    d3 = d1 + d2;
    cout<<"Addition of Date 1 and Date 2: ";
    d3.display();

    bool lessthan = d1<d2;
    cout<<"d1 < d2: ";
    if(lessthan==0){
        cout<<"Date 1 is older than Date 2 "<<endl;
    }
    else{
        cout<<"Date 2 is older than Date 1 "<<endl;
    }

    bool isequal = d1==d2;
    cout<<"d1 == d2: ";
    if(isequal==0){
        cout<<"Date 1 and Date 2 are not Same. "<<endl;
    }
    else{
        cout<<"Date1 and Date 2 are Same. "<<endl;
    }

    bool notequal = d1!=d2;
    cout<<"d1 != d2: ";
    if(notequal==0){
        cout<<"Date 1 and Date 2 are Same. "<<endl;
    }
    else{
        cout<<"Date1 and Date 2 are not Same. "<<endl;
    }

    return 0;
}