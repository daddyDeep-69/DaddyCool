#include<iostream>
#include"Player.h"
using namespace std;

Player::Player() {
    name = "";
    age = 0;
    country = "";
}

Player::Player(string n, int a, string c)
{
    name = n;
    age = a;
    country = c;
}

void Player::accept()
{
    cout<<"Enter player's name: ";
    cin>>name;
    cout<<"Enter player's age: ";
    cin>>age;
    cout<<"Enter player's country: ";
    cin>>country;
    cout<<endl;
}

void Player::display()
{
    cout<<"\tPlayer Details:"<<endl;
    cout<<"Name: "<<name<<endl;
    cout<<"Age: "<<age<<endl;
    cout<<"Country: "<<country<<endl;
    cout<<endl;

}

string Player::getname()
{
    return name;
}

int Player::getage()
{
    return age;
}

void sortName(Player P[], int n)
{
    for(int i=0;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(P[i].getname() > P[j].getname() ||
              (P[i].getname()==P[j].getname() && P[i].getage()>P[j].getage()))
            {
                Player temp = P[i];
                P[i] = P[j];
                P[j] = temp;
            }
        }
    }
}


Player::~Player()
{}