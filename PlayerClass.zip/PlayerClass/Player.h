#include<iostream>
#include<string>
using namespace std;
class Player
{
    private:
    string name;
    int age;
    string country;

    public:
    Player();
    Player(string n, int a, string c);
    void accept();
    void display();
    string getname();
    int getage();
    ~Player();
};

void sortName(Player P[], int n);