#include<iostream>
#include"Player.h"
using namespace std;

int main()
{
    int n;

    cout<<"Enter number of player to enter: ";
    cin>>n;

    Player P[n];

    for(int i=0; i<n; i++)
    {
        P[i].accept();
    }

    for (int i=0; i<n; i++)
    {
        P[i].display();
    }
    
    sortName(P, n);

    for (int i=0; i<n; i++)
    {
        P[i].display();
    }

    return 0;
}