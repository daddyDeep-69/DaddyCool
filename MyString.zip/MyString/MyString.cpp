#include<iostream>
#include "MyString.h"
using namespace std;

MyString::MyString(){

    p= new char[00];
    size=0;

}

MyString::MyString(int n){
    
    p= new char[n];
    size=n;
    for(int i=0;i<n;i++){
        cout<<"Enter "<<i<<" Data: ";
        cin>>p[i];
    }
}

void MyString::displayFun(){
    cout<<"Data: ";
    for(int i=0;i<size;i++){
        cout<<p[i];
    }
    cout<<endl;
}

MyString::MyString(MyString &Str1){
    for(int i=0;i<size;i++){
        this->p[i]= Str1.p[i];
    }
}

MyString::~MyString(){
    cout<<"Destructor Called"<<endl;
    delete[] p;
}