#include<iostream>
#include "MyString.h"
using namespace std;

int main(){
    int n;
    cout<<"Enter Size of String: ";
    cin>>n;

    MyString str1(n);
    str1.displayFun();
    return 0;
}