class MyString{

    private:
    char *p;
    int size;

    public:
    MyString();
    MyString(int n);
    MyString(MyString &Str1);
    void displayFun();
    ~MyString();
};